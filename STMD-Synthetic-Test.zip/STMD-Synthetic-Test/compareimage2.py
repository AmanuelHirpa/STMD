# -*- coding: utf-8 -*-
"""
Created on Mon Nov 12 23:29:14 2018

@author: Amanuel Hirpa #Automatic image annotaion using image's color information.
#An input for Mask-RCNN
"""
# USAGE
# python compare.py

# import the necessary packages
#from skimage.measure import structural_similarity as ssim
from skimage import measure
import matplotlib.pyplot as plt
import numpy as np
import cv2

import os,cv2
import numpy as np
import cv2 as cv
import json
PATH = os.getcwd()
data_path = PATH + '/GT'
data_dir_list = os.listdir(data_path)
img_data_list=[]
PATH2 = os.getcwd()
data_path2 = PATH2 + '/results'
data_dir_list2 = os.listdir(data_path2)
img_data_list2=[]
x=[]
y=[]
dictt={}
b=0
c=0
d=0
def mse(imageA, imageB):
	# the 'Mean Squared Error' between the two images is the
	# sum of the squared difference between the two images;
	# NOTE: the two images must have the same dimension
	err = np.sum((imageA.astype("float") - imageB.astype("float")) ** 2)
	err /= float(imageA.shape[0] * imageA.shape[1])
	
	# return the MSE, the lower the error, the more "similar"
	# the two images are
	return err



for dataset in data_dir_list:
    img_list=sorted(os.listdir(data_path+'/'+ dataset))
    #print ('Loaded the images of dataset-'+'{}\n'.format(dataset))
    for img in img_list:
        
        input_img=cv2.imread(data_path + '/'+ dataset + '/'+ img,cv2.IMREAD_COLOR ) 
        for dataset2 in data_dir_list2:
            img_list2=sorted(os.listdir(data_path2+'/'+ dataset2))
            #print ('Loaded the images of dataset-'+'{}\n'.format(dataset2))
     
            for img2 in img_list2:
        
                input_img2=cv2.imread(data_path2 + '/'+ dataset2 + '/'+ img2,cv2.IMREAD_COLOR ) 
                if str(img)== str(img2):
                     original1 = cv2.cvtColor(input_img, cv2.COLOR_BGR2GRAY)
                     original2 = cv2.cvtColor(input_img2, cv2.COLOR_BGR2GRAY)
                     #print(str(img))
                     #print(str(img2))
                     #cv2.imwrite("xx.jpg",input_img)
                     #cv2.imwrite("xxx.jpg",input_img2)
                     a=mse(input_img,input_img2)
                     ssim=measure.compare_ssim(original1,original2)
                     psnr=measure.compare_psnr(original1,original2)
                     print("mse: "+str(a))
                     print("--------------------------")
                     b=a+b
                     print("ssim: "+str(ssim))
                     print("--------------------------")
                     c=ssim+c 
                     print("psnr: "+str(psnr))
                     print("--------------------------")
                     d=psnr+d 
print("++++++++++++++++++++++++++++++++++++++++++++") 
print("total")
print("--------------------------")
print("mse")
print(b/15)
print("--------------------------")
print("ssim")
print(c/15)
print("--------------------------")
print("psnr")
print(d/15)
print("--------------------------")                     
           
            


